## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib simmr, .registration = TRUE
## usethis namespace: end
NULL
